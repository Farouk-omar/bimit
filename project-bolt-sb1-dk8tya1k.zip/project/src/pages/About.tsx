import React from 'react';
import { 
  Users, 
  Globe, 
  Award, 
  Target, 
  CheckCircle, 
  Building2,
  Lightbulb,
  Shield
} from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: Target,
      title: 'Innovation',
      description: 'We leverage cutting-edge BIM technologies to deliver innovative solutions that push the boundaries of architectural and engineering design.'
    },
    {
      icon: Shield,
      title: 'Quality',
      description: 'Our commitment to international standards ensures every project meets the highest quality benchmarks and exceeds client expectations.'
    },
    {
      icon: Users,
      title: 'Collaboration',
      description: 'We foster seamless collaboration between all stakeholders, creating an integrated workflow that enhances project efficiency.'
    },
    {
      icon: Lightbulb,
      title: 'Expertise',
      description: 'Our multidisciplinary team brings deep expertise in BIM modeling, automation, and collaborative design methodologies.'
    }
  ];

  const achievements = [
    { number: '50+', label: 'Completed Projects' },
    { number: '10+', label: 'Years of Experience' },
    { number: '100+', label: 'Trained Professionals' },
    { number: '15+', label: 'Countries Served' }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              About BIM IT
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed mb-8">
              We are a multidisciplinary team of architects and engineers specializing in Building Information Modeling (BIM), 
              delivering innovative, cost-effective, and collaborative design solutions that transform the construction industry.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
                <p className="text-lg text-gray-600 leading-relaxed mb-6">
                  To revolutionize the architecture and engineering industry through innovative BIM solutions 
                  that reduce project downtime, minimize costs, and deliver exceptional value to our clients.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Deliver projects that exceed international standards</span>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Provide comprehensive BIM training and certification</span>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">Foster innovation in construction technology</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-8 text-white">
                <Building2 className="w-16 h-16 mb-6" />
                <h3 className="text-2xl font-bold mb-4">Our Expertise</h3>
                <ul className="space-y-3 text-blue-100">
                  <li>• Advanced BIM Modeling & Visualization</li>
                  <li>• Project Management & Coordination</li>
                  <li>• Professional Training & Certification</li>
                  <li>• Workflow Automation & Optimization</li>
                  <li>• International Standards Compliance</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Our Core Values
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The principles that guide our work and define our commitment to excellence
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div
                  key={index}
                  className="bg-white rounded-xl p-8 text-center shadow-lg hover:shadow-xl transition-all duration-300 group border border-gray-100"
                >
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-blue-600 transition-colors duration-300">
                    <Icon className="w-8 h-8 text-blue-600 group-hover:text-white transition-colors duration-300" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">{value.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Our Achievements
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Numbers that reflect our commitment to excellence and client satisfaction
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl lg:text-5xl font-bold text-blue-600 mb-2">
                  {achievement.number}
                </div>
                <div className="text-lg text-gray-600 font-medium">
                  {achievement.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Philosophy */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold mb-6">
                Why Choose BIM IT?
              </h2>
              <p className="text-xl text-blue-100 leading-relaxed mb-8">
                Our multidisciplinary approach combines architectural creativity with engineering precision, 
                enhanced by cutting-edge BIM technology to deliver projects that set new industry standards.
              </p>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Globe className="w-6 h-6 text-blue-200" />
                  <span className="text-blue-100">International standards compliance</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Award className="w-6 h-6 text-blue-200" />
                  <span className="text-blue-100">Certified professionals and expertise</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Users className="w-6 h-6 text-blue-200" />
                  <span className="text-blue-100">Collaborative and integrated approach</span>
                </div>
              </div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8">
              <h3 className="text-2xl font-bold mb-6">Our Commitment</h3>
              <div className="space-y-4 text-blue-100">
                <p>
                  We are committed to reducing project downtime and costs while delivering better value 
                  for our clients through innovative BIM solutions and collaborative methodologies.
                </p>
                <p>
                  Our experience in modeling, automation, and collaboration ensures that every project 
                  benefits from the latest technologies and industry best practices.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;